# This file will only exist on the production server

# Production database settings
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'raotsup1_raotdb',
        'USER': 'raotsup1_raotuser',
        'PASSWORD': 'your_actual_password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}

# Local development settings

# Use SQLite for local development
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': 'db.sqlite3',
    }
}

# Enable debug for development
DEBUG = True

# Allow localhost
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']

# Development secret key
SECRET_KEY = 'django-insecure-q$@10ubp67y+hd^rqsja4&pnne$fg-yai8pf^c62#x4%2etjo6'