// Admin functionality
$(document).ready(function() {
  console.log('Admin JS loaded');
  
  // Add any additional admin functionality here
});
