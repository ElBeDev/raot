# Deployment Instructions

## 1. Upload Files to Server
Upload all project files to your server.

## 2. SSH into Your Server
```bash
# SSH into your server
ssh root@69.62.95.109